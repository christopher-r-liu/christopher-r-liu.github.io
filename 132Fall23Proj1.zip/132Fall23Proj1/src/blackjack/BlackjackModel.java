package blackjack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import deckOfCards.*;
/** This class represents a Blackjack model that facilitates 
 *  a Blackjack game through its methods. These methods allow
 *  the player and dealer to take cards from the deck and 
 *  restricts the dealer on when it can take cards. This class
 *  also provides methods that help determine if the dealer or the player won
 *  by first calculating the sum of card values for the dealer's and player's
 *  hands and then comparing these values to determine if the player won,
 *  lost, achieved a natural blackjack, or if the player and dealer tied.
 * 
 * Chris Liu
 */
public class BlackjackModel {

	private ArrayList<Card> dealerCards; //represents the cards in the dealer's hand
	private ArrayList<Card> playerCards; //represents the cards in the player's hand
	private Deck deck; //represents the deck of cards that are currently unused
	
	//creates a new deck and shuffles the cards according to the parameter
	public void createAndShuffleDeck(Random random) {

		deck = new Deck();
		deck.shuffle(random);
	}
	
	//returns a copy of the ArrayList that contains the dealer's cards
	public ArrayList<Card> getDealerCards() {

		return new ArrayList<Card>(dealerCards);
	}
	
	//returns a copy of the ArrayList that contains the player's cards
	public ArrayList<Card> getPlayerCards(){
		
		return new ArrayList<Card>(playerCards);
	}
	
	//changes the dealer's cards to that of the parameter
	public void setDealerCards(ArrayList<Card> cards) {
		
		dealerCards = new ArrayList<Card>(cards);
	}

	//changes the player's cards to that of the parameter
	public void setPlayerCards(ArrayList<Card> cards) {
		
		playerCards = new ArrayList<Card>(cards);
	}

	//gets an initial two cards for the dealer's hand
	public void initialDealerCards() {

		dealerCards = new ArrayList<Card>();
		initialHandHelper(dealerCards);
	}
	
	//gets an initial two cards for the player's hand
	public void initialPlayerCards() {

		playerCards = new ArrayList<Card>();
		initialHandHelper(playerCards);
	}
	
	//helper method that gets two initial cards for a player or dealer's hand
	private void initialHandHelper(ArrayList<Card> cards) {
		
		for(int cardNumber = 0; cardNumber < 2; cardNumber++) {
			
			cards.add(deck.dealOneCard());
		}
	}

	//removes one card from the deck and gives it to the dealer
	public void dealerTakeCard() {

		dealerCards.add(deck.dealOneCard());
	}
	
	//removes one card from the deck and gives it to the player
	public void playerTakeCard() {

		playerCards.add(deck.dealOneCard());
	}

	//returns an ArrayList containing all the possible values of the cards' sum
	public static ArrayList<Integer> possibleHandValues(ArrayList<Card> hand) {

		ArrayList<Integer> possibleValues = new ArrayList<Integer>();
		
		int minVal = 0; //represents the minimum possible value for the sum of cards
		int maxVal = 0; //represents the maximum possible value for the sum of cards
		
		//calculates sum of card values
		for(Card card : hand) {
			
			int curCardRankValue = card.getRank().getValue();
			
			minVal += curCardRankValue;
			maxVal += curCardRankValue;
			
			//has the maximum value add the value of 11 for an Ace if the resulting sum doesn't surpass 21 
			if(curCardRankValue == 1 && maxVal + 10 <= 21) {
				maxVal += 10;
			}
		}
		
		possibleValues.add(minVal);
		
		//adds a second card sum value to the ArrayList if it is greater than the minimum value but not over 21
		if(maxVal > minVal && maxVal <= 21) {
			
			possibleValues.add(maxVal);
		}
		
		return possibleValues;
	}
	
	//returns an Enum value that represents state of the hand
	public static HandAssessment assessHand(ArrayList<Card> hand) {
		
		if(hand == null || hand.size() < 2) {
			
			return HandAssessment.INSUFFICIENT_CARDS;
		}
		
		ArrayList<Integer> possibleHandValues = possibleHandValues(hand);
		if(hand.size() == 2 && possibleHandValues.contains(21)) {
			
			return HandAssessment.NATURAL_BLACKJACK;
		}
		
		if(possibleHandValues.get(0) > 21) {
			
			return HandAssessment.BUST;
		}
		
		return HandAssessment.NORMAL;
	}

	//returns an Enum value that represents game status
	public GameResult gameAssessment() {

		HandAssessment playerAssessment = assessHand(playerCards);
		HandAssessment dealerAssessment = assessHand(dealerCards);
		
		if(playerAssessment == HandAssessment.BUST) {
			
			return GameResult.PLAYER_LOST;
		}
		
		//checks if the player has a natural blackjack and returns game result based on the dealer's hand status
		if(playerAssessment == HandAssessment.NATURAL_BLACKJACK) {
			
			if(dealerAssessment != HandAssessment.NATURAL_BLACKJACK) {
			
				return GameResult.NATURAL_BLACKJACK;
			}
			
			return GameResult.PUSH;
		}
		
		if(dealerAssessment == HandAssessment.BUST) {
			
			return GameResult.PLAYER_WON;
		}
		
		ArrayList<Integer> playerCardValues = possibleHandValues(playerCards);
		ArrayList<Integer> dealerCardValues = possibleHandValues(dealerCards);
		
		//gets the maximum card sum value from each hand and then compares the sums to each other and returns a Game Result based on these results
		int playerCardValue = playerCardValues.get(playerCardValues.size() - 1);
		int dealerCardValue = dealerCardValues.get(dealerCardValues.size() - 1);
		
		if(playerCardValue > dealerCardValue) {
			
			return GameResult.PLAYER_WON;
		}
		
		if(playerCardValue < dealerCardValue) {
			
			return GameResult.PLAYER_LOST;
		}
		
		return GameResult.PUSH;
	}
	
	//determines if dealer should take card, with a boolean value of true representing yes and vice versa
	public boolean dealerShouldTakeCard() {

		ArrayList<Integer> possibleHandValues = possibleHandValues(dealerCards);
		
		//determines if the sum of card values can be interpreted in more than 1 way
		if(possibleHandValues.size() == 1) {
			
			if(possibleHandValues.get(0) <= 16) {
				
				return true;
			}
			
			return false;
		}
		
		//if the sum can be determined in more than one way, it will return true if the maximum value doesn't surpass 17
		if(possibleHandValues.get(1) < 18) {
			
			return true;
		}
		
		return false;
	}

}
