package deckOfCards;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
/** This class represents a deck that contains 52 playing cards
 * and provides methods that allows the client to shuffle the deck and to remove and return the first card in the deck.
 * 
 * Chris Liu
 *
 */
public class Deck {

	private ArrayList<Card> cards; //ArrayList containing all the cards needed for Blackjack
	
	//creates the deck by initializing an ArrayList of cards
	public Deck() {
		
		cards = new ArrayList<Card>();
		
		//adds the 52 cards to the deck with unique suit-rank combinations for each card
		for(Suit suit: Suit.values()) {
			for(Rank rank: Rank.values()) {
				cards.add(new Card(rank, suit));
			}
		}
	}
	
	//removes and returns the first card in the deck
	public Card dealOneCard() {
		
		return cards.remove(0);
	}
	
	//shuffles the deck according to the parameter
	public void shuffle(Random randomNumberGenerator) {
		
		Collections.shuffle(cards, randomNumberGenerator);
	}
	
	
}
