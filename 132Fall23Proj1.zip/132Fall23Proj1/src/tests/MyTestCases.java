package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyTestCases {

	@Test
	public void test() {
		
	}

}
